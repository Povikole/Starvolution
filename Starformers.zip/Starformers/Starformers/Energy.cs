﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Starformers
{
    public class Energy : Sprite
    {
        public Energy(Texture2D texture, Vector2 position, Vector2 place) : base(texture, position, place)
        {
            sprite_width = 40;
            sprite_height = 68;
            sprite_distance_from_right = 28;
            sprite_distance_from_top = 14;
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(_texture, _position, new Rectangle((int)_texturePlace.X * 96,
            (int)_texturePlace.Y * 96,
            96, 96), Color.White, 0f,
            new Vector2(_texture.Width /6, _texture.Height / 7), 1, SpriteEffects.None, 1);
        }
    }
}
