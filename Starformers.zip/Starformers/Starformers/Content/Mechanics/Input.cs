﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace Starformers
{
    public class Input
    {
        public Keys left { get; set; }
        public Keys right { get; set; }
        public Keys up { get; set; }
        public Keys down { get; set; }
        public Keys small { get; set; }
        public Keys normal { get; set; }
        public Keys big { get; set; }
        public Keys info { get; set; }
        public Keys e { get; set; }
    }
}
