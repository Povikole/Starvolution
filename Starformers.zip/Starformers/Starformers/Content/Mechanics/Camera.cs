﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace Starformers
{
    public class Camera
    {
        public Matrix Transform { get; private set; }
        public void Follow(Player target)
        {
            var position = Matrix.CreateTranslation(
                -target._position.X + (target._texture.Width / 6),
                -target._position.Y - (target._texture.Height / 6),
                0);
            var ofset = Matrix.CreateTranslation(
                    Game1.screenHeight / 2,
                    Game1.screenWidth / 2,
                    0);
            Transform = position * ofset;
        }
    }
}
