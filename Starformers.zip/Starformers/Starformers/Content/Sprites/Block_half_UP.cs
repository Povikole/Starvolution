﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Starformers
{
    public class Block_half_UP : Sprite
    {
        public Block_half_UP(Texture2D texture, Vector2 position, Vector2 texturePlace) :
            base(texture, position, texturePlace)
        {
            sprite_width = 96;
            sprite_height = 48;
        }
    }
}
