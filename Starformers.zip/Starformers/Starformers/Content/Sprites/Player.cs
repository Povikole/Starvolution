﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Starformers
{
    public class Player : Sprite
    {
        public bool is_normal;
        public bool is_small;
        public bool is_big;
        public Vector2 velocity;
        public Input input;
        protected float gravity;
        protected int mass;
        protected bool is_flipped;
        protected bool is_walking;
        protected bool is_midair;
        protected bool is_yummy_yummy_time;
        protected float _distance;
        protected bool is_colliding;
        protected int timer_player;
        protected bool transform;
        protected int timer_transformation;
        public Player(Texture2D texture, Vector2 position) : base(texture, position)
        {
            velocity = new Vector2(3, 0);
            is_midair = false;
            is_colliding = false;
            is_flipped = false;
            is_walking = false;
            sprite_width = 90;
            sprite_height = 90;
            sprite_distance_from_right = 3;
            sprite_distance_from_top = 6;
            gravity = 0.20f;
            is_normal = false;
            is_small = false;
            is_big = true;
            is_yummy_yummy_time = false;
            transform = false;
        }
        public override void Update(GameTime gameTime, List<Sprite> sprites)
        {
            Move(gameTime, sprites);
            Game1._camera.Follow(this);
            if (_position.Y >= 1000) Game1.is_dead = true;
            if (timer_player < 75) timer_player++;
            else timer_player = 0;
            if (timer_transformation < 35) timer_transformation++;
            else timer_transformation = 0;
        }
        private void Move(GameTime gameTime, List<Sprite> sprites)
        {
            if (input == null)
                return;
            var kstate = Keyboard.GetState();

            if (kstate.IsKeyDown(input.info))
            {
                Game1.show_info = true;
                return;
            }
            else Game1.show_info = false;
            if (kstate.IsKeyDown(input.e))
            {
                Game1.show_energy = true;
                return;
            }
            else Game1.show_energy = false;


            if (kstate.IsKeyDown(input.small) && !is_small && !is_midair && Game1.points > 0)
            {
                is_normal = false;
                is_big = false;
                is_small = true;
                sprite_width = 42;
                sprite_height = 42;
                sprite_distance_from_right = 27;
                sprite_distance_from_top = 54;
                gravity = 0.24f;
                velocity = new Vector2(4, 0);
                Game1.points--;
            }
            if (kstate.IsKeyDown(input.normal) && !is_normal && !is_midair && Game1.points > 0)
            {
                if (is_small)
                {
                    transform = true;
                    timer_transformation = 0;
                }
                is_normal = true;
                is_big = false;
                is_small = false;
                sprite_width = 66;
                sprite_height = 66;
                sprite_distance_from_right = 15;
                sprite_distance_from_top = 30;
                gravity = 0.26f;
                velocity = new Vector2(6, 0);
                Game1.points--;
            }
            if(kstate.IsKeyUp(input.big))
            if(kstate.IsKeyDown(input.big) && !is_big && !is_midair && Game1.points > 0)
            {
                is_normal = false;
                is_big = true;
                is_small = false;
                sprite_width = 90;
                sprite_height = 90;
                sprite_distance_from_right = 3;
                sprite_distance_from_top = 6;
                gravity = 0.20f;
                velocity = new Vector2(3, 0);
                Game1.points--;
            }
            if (kstate.IsKeyDown(input.up) && !is_midair)
            {
                velocity.Y = -10f;
                is_midair = true;
            }
            if (kstate.IsKeyDown(input.right))
            {
                if (!Is_colliding_right(sprites))
                {
                    _position.X += velocity.X;
                    is_walking = true;
                }
                else is_walking = false;
                is_flipped = false;
            }
            if (kstate.IsKeyDown(input.left))
            {
                if (!Is_colliding_left(sprites))
                {
                    _position.X -= velocity.X;
                    is_walking = true;
                }
                else is_walking = false;
                is_flipped = true;
            }
            else if (kstate.IsKeyUp(input.left) && kstate.IsKeyUp(input.right))
                is_walking = false;
            Is_colliding_top(sprites);
            if (is_colliding)
            {
                _position.Y -= _distance;
                velocity.Y = -velocity.Y;
                return;
            }
            Is_colliding_bottom(sprites);
            if (is_colliding)
            {
                velocity.Y = 0;
                is_midair = false;
                if (_distance != 0)
                {
                    _position.Y += _distance;
                    _distance = 0;
                }
            }
            else
            {
                is_midair = true;
                _position.Y += velocity.Y;
                velocity.Y += gravity;
            }
        }
        void Is_colliding_top(List<Sprite> sprites)
        {
            foreach (var sprite1 in sprites)
            {
                if (this == sprite1 || sprite1.is_removed)
                    continue;
                if (hitbox.Top + velocity.Y < sprite1.hitbox.Bottom &&
                    hitbox.Bottom > sprite1.hitbox.Top &&
                    hitbox.Left < sprite1.hitbox.Right &&
                    hitbox.Right > sprite1.hitbox.Left)
                {
                    if (sprite1 is Energy)
                    {
                        sprite1.is_removed = true;
                        Game1.points += 3;
                        if (is_big) is_yummy_yummy_time = true;
                        timer_player = 0;
                        continue;
                    }
                    if (sprite1 is Blakc_hole)
                    {
                        Game1.is_dead = true;
                    }
                    if (sprite1 is Finish)
                    {
                        Game1.is_completed = true;
                    }
                    is_colliding = true;
                    _distance = hitbox.Top - sprite1.hitbox.Bottom; return;
                }
            }
            is_colliding = false;
        }
        private bool Is_colliding_right(List<Sprite> sprites)
        {
            foreach (var sprite1 in sprites)
            {
                if (this == sprite1 || sprite1.is_removed)
                    continue;
                if (hitbox.Right + velocity.X > sprite1.hitbox.Left &&
                    hitbox.Left < sprite1.hitbox.Right &&
                    hitbox.Top < sprite1.hitbox.Bottom &&
                    hitbox.Bottom > sprite1.hitbox.Top)
                {
                    if (sprite1 is Energy)
                    {
                        sprite1.is_removed = true;
                        Game1.points += 3;
                        if (is_big) is_yummy_yummy_time = true;
                        timer_player = 0;
                        continue;
                    }
                    if (sprite1 is Blakc_hole)
                    {
                        Game1.is_dead = true;
                    }
                    if (sprite1 is Finish)
                    {
                        Game1.is_completed = true;
                    }
                    return true;
                }
            }
            return false;
        }
        private bool Is_colliding_left(List<Sprite> sprites)
        {
            foreach (var sprite1 in sprites)
            {
                if (this == sprite1 || sprite1.is_removed)
                    continue;
                if (hitbox.Left - velocity.X < sprite1.hitbox.Right &&
                    hitbox.Right > sprite1.hitbox.Left &&
                    hitbox.Top < sprite1.hitbox.Bottom &&
                    hitbox.Bottom > sprite1.hitbox.Top)
                {
                    if (sprite1 is Energy)
                    {
                        sprite1.is_removed = true;
                        Game1.points += 3;
                        if (is_big) is_yummy_yummy_time = true;
                        timer_player = 0;
                        continue;
                    }
                    if (sprite1 is Blakc_hole)
                    {
                        Game1.is_dead = true;
                    }
                    if (sprite1 is Finish)
                    {
                        Game1.is_completed = true;
                    }
                    return true;
                }
            }
            return false;
        }
        private void Is_colliding_bottom(List<Sprite> sprites)
        {
            foreach (var sprite1 in sprites)
            {
                if (this == sprite1 || sprite1.is_removed)
                    continue;
                if (hitbox.Bottom + velocity.Y >= sprite1.hitbox.Top &&
                    hitbox.Top < sprite1.hitbox.Bottom &&
                    hitbox.Left < sprite1.hitbox.Right &&
                    hitbox.Right > sprite1.hitbox.Left)
                {
                    if (sprite1 is Energy)
                    {
                        sprite1.is_removed = true;
                        Game1.points += 3;
                        if(is_big) is_yummy_yummy_time = true;
                        timer_player = 0;
                        continue;
                    }
                    if(sprite1 is Blakc_hole)
                    {
                        Game1.is_dead = true;
                    }
                    if(sprite1 is Finish)
                    {
                        Game1.is_completed = true;
                    }
                    is_colliding = true;
                    _distance = sprite1.hitbox.Top - hitbox.Bottom; return;
                }
            }
            is_colliding = false;
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            if(!is_flipped)
            {
                if (is_normal)
                {
                    if(transform)
                    {
                        if(timer_transformation < 7)
                        {
                            spriteBatch.Draw(_texture, _position, new Rectangle(
                                    480, 96, 96, 96), Color.White, 0f,
                                    new Vector2(_texture.Width / 6, _texture.Height / 7),
                                    1, SpriteEffects.None, 1);
                            return;
                        }
                        if(timer_transformation < 14)
                        {
                            spriteBatch.Draw(_texture, _position, new Rectangle(
                                    0, 192, 96, 96), Color.White, 0f,
                                    new Vector2(_texture.Width / 6, _texture.Height / 7),
                                    1, SpriteEffects.None, 1);
                            return;
                        }
                        if(timer_transformation < 21)
                        {
                            spriteBatch.Draw(_texture, _position, new Rectangle(
                                    96, 192, 96, 96), Color.White, 0f,
                                    new Vector2(_texture.Width / 6, _texture.Height / 7),
                                    1, SpriteEffects.None, 1);
                            return;
                        }
                        if(timer_transformation < 28)
                        {
                            spriteBatch.Draw(_texture, _position, new Rectangle(
                                    192, 192, 96, 96), Color.White, 0f,
                                    new Vector2(_texture.Width / 6, _texture.Height / 7),
                                    1, SpriteEffects.None, 1);
                            return;
                        }
                        if(timer_transformation < 35)
                        {
                            spriteBatch.Draw(_texture, _position, new Rectangle(
                                    288, 192, 96, 96), Color.White, 0f,
                                    new Vector2(_texture.Width / 6, _texture.Height / 7),
                                    1, SpriteEffects.None, 1);
                            timer_transformation = 0;
                            transform = false;
                            return;
                        }
                    }
                    if (is_midair)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                    288, 96, 96, 96), Color.White, 0f,
                                    new Vector2(_texture.Width / 6, _texture.Height / 7),
                                    1, SpriteEffects.None, 1);
                        return;
                    }
                    if (is_walking)
                    {
                        if (timer_player < 15)
                        {
                            spriteBatch.Draw(_texture, _position, new Rectangle(
                                    96, 96, 96, 96), Color.White, 0f,
                                    new Vector2(_texture.Width / 6, _texture.Height / 7),
                                    1, SpriteEffects.None, 1);
                            return;
                        }
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                192, 96, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.None, 1);
                        if (timer_player == 29) timer_player = 0;
                        return;
                    }
                    if(timer_player < 15)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                480, 0, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.None, 1);
                        return;
                    }
                    spriteBatch.Draw(_texture, _position, new Rectangle(
                            0, 96, 96, 96), Color.White, 0f,
                            new Vector2(_texture.Width / 6, _texture.Height / 7),
                            1, SpriteEffects.None, 1);
                    if(timer_player == 29) timer_player = 0;
                    return;
                }
                if (is_big)
                {
                    if(is_yummy_yummy_time)
                    {
                        if(timer_player < 7)
                        {
                            spriteBatch.Draw(_texture, _position, new Rectangle(
                                    288, 384, 96, 96), Color.White, 0f,
                                    new Vector2(_texture.Width / 6, _texture.Height / 7),
                                    1, SpriteEffects.None, 1);
                            return;
                        }
                        if(timer_player < 14)
                        {
                            spriteBatch.Draw(_texture, _position, new Rectangle(
                                    384, 384, 96, 96), Color.White, 0f,
                                    new Vector2(_texture.Width / 6, _texture.Height / 7),
                                    1, SpriteEffects.None, 1);
                            return;
                        }
                        if(timer_player < 21)
                        {
                            spriteBatch.Draw(_texture, _position, new Rectangle(
                                    480, 384, 96, 96), Color.White, 0f,
                                    new Vector2(_texture.Width / 6, _texture.Height / 7),
                                    1, SpriteEffects.None, 1);
                            return;
                        }
                        if(timer_player < 28)
                        {
                            spriteBatch.Draw(_texture, _position, new Rectangle(
                                    0, 480, 96, 96), Color.White, 0f,
                                    new Vector2(_texture.Width / 6, _texture.Height / 7),
                                    1, SpriteEffects.None, 1);
                            return;
                        }
                        if(timer_player < 40)
                        {
                            spriteBatch.Draw(_texture, _position, new Rectangle(
                                    96, 480, 96, 96), Color.White, 0f,
                                    new Vector2(_texture.Width / 6, _texture.Height / 7),
                                    1, SpriteEffects.None, 1);
                            timer_player = 0;
                            is_yummy_yummy_time = false;
                            return;
                        }
                    }
                    if (is_midair)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                    384, 0, 96, 96), Color.White, 0f,
                                    new Vector2(_texture.Width / 6, _texture.Height / 7),
                                    1, SpriteEffects.None, 1);
                        return;
                    }
                    if (is_walking)
                    {
                        if (timer_player < 15)
                        {
                            spriteBatch.Draw(_texture, _position, new Rectangle(
                                    192, 0, 96, 96), Color.White, 0f,
                                    new Vector2(_texture.Width / 6, _texture.Height / 7),
                                    1, SpriteEffects.None, 1);
                            return;
                        }
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                288, 0, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.None, 1);
                        if (timer_player == 29) timer_player = 0;
                        return;
                    }
                    if (timer_player < 15)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                0, 0, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.None, 1);
                        return;
                    }
                    spriteBatch.Draw(_texture, _position, new Rectangle(
                            96, 0, 96, 96), Color.White, 0f,
                            new Vector2(_texture.Width / 6, _texture.Height / 7),
                            1, SpriteEffects.None, 1);
                    if (timer_player == 29) timer_player = 0;
                    return;
                }
                if (is_small)
                {
                    if (is_midair)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                    192, 288, 96, 96), Color.White, 0f,
                                    new Vector2(_texture.Width / 6, _texture.Height / 7),
                                    1, SpriteEffects.None, 1);
                        return;
                    }
                    if (is_walking)
                    {
                        if (timer_player < 15)
                        {
                            spriteBatch.Draw(_texture, _position, new Rectangle(
                                    0, 288, 96, 96), Color.White, 0f,
                                    new Vector2(_texture.Width / 6, _texture.Height / 7),
                                    1, SpriteEffects.None, 1);
                            return;
                        }
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                96, 288, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.None, 1);
                        if (timer_player == 29) timer_player = 0;
                        return;
                    }
                    if (timer_player < 15)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                384, 96, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.None, 1);
                        return;
                    }
                    spriteBatch.Draw(_texture, _position, new Rectangle(
                            96, 288, 96, 96), Color.White, 0f,
                            new Vector2(_texture.Width / 6, _texture.Height / 7),
                            1, SpriteEffects.None, 1);
                    if (timer_player == 29) timer_player = 0;
                    return;
                }
            }
            // flipped
            if (is_normal)
            {
                if (transform)
                {
                    if (timer_transformation < 7)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                480, 96, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.FlipHorizontally, 1);
                        return;
                    }
                    if (timer_transformation < 14)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                0, 192, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.FlipHorizontally, 1);
                        return;
                    }
                    if (timer_transformation < 21)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                96, 192, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.FlipHorizontally, 1);
                        return;
                    }
                    if (timer_transformation < 28)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                192, 192, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.FlipHorizontally, 1);
                        return;
                    }
                    if (timer_transformation < 35)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                288, 192, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.FlipHorizontally, 1);
                        timer_transformation = 0;
                        transform = false;
                        return;
                    }
                }
                if (is_midair)
                {
                    spriteBatch.Draw(_texture, _position, new Rectangle(
                                288, 96, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.FlipHorizontally, 1);
                    return;
                }
                if (is_walking)
                {
                    if (timer_player < 15)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                96, 96, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.FlipHorizontally, 1);
                        return;
                    }
                    spriteBatch.Draw(_texture, _position, new Rectangle(
                            192, 96, 96, 96), Color.White, 0f,
                            new Vector2(_texture.Width / 6, _texture.Height / 7),
                            1, SpriteEffects.FlipHorizontally, 1);
                    if (timer_player == 29) timer_player = 0;
                    return;
                }
                if (timer_player < 15)
                {
                    spriteBatch.Draw(_texture, _position, new Rectangle(
                            480, 0, 96, 96), Color.White, 0f,
                            new Vector2(_texture.Width / 6, _texture.Height / 7),
                            1, SpriteEffects.FlipHorizontally, 1);
                    return;
                }
                spriteBatch.Draw(_texture, _position, new Rectangle(
                        0, 96, 96, 96), Color.White, 0f,
                        new Vector2(_texture.Width / 6, _texture.Height / 7),
                        1, SpriteEffects.FlipHorizontally, 1);
                if (timer_player == 29) timer_player = 0;
                return;
            }
            if (is_big)
            {
                if (is_yummy_yummy_time)
                {
                    if (timer_player < 7)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                288, 384, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.FlipHorizontally, 1);
                        return;
                    }
                    if (timer_player < 14)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                384, 384, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.FlipHorizontally, 1);
                        return;
                    }
                    if (timer_player < 21)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                480, 384, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.FlipHorizontally, 1);
                        return;
                    }
                    if (timer_player < 28)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                0, 480, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.FlipHorizontally, 1);
                        return;
                    }
                    if (timer_player < 40)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                96, 480, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.FlipHorizontally, 1);
                        timer_player = 0;
                        is_yummy_yummy_time = false;
                        return;
                    }
                }
                if (is_midair)
                {
                    spriteBatch.Draw(_texture, _position, new Rectangle(
                                384, 0, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.FlipHorizontally, 1);
                    return;
                }
                if (is_walking)
                {
                    if (timer_player < 15)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                192, 0, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.FlipHorizontally, 1);
                        return;
                    }
                    spriteBatch.Draw(_texture, _position, new Rectangle(
                            288, 0, 96, 96), Color.White, 0f,
                            new Vector2(_texture.Width / 6, _texture.Height / 7),
                            1, SpriteEffects.FlipHorizontally, 1);
                    if (timer_player == 29) timer_player = 0;
                    return;
                }
                if (timer_player < 15)
                {
                    spriteBatch.Draw(_texture, _position, new Rectangle(
                            0, 0, 96, 96), Color.White, 0f,
                            new Vector2(_texture.Width / 6, _texture.Height / 7),
                            1, SpriteEffects.FlipHorizontally, 1);
                    return;
                }
                spriteBatch.Draw(_texture, _position, new Rectangle(
                        96, 0, 96, 96), Color.White, 0f,
                        new Vector2(_texture.Width / 6, _texture.Height / 7),
                        1, SpriteEffects.FlipHorizontally, 1);
                if (timer_player == 29) timer_player = 0;
                return;
            }
            if (is_small)
            {
                if (is_midair)
                {
                    spriteBatch.Draw(_texture, _position, new Rectangle(
                                192, 288, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.FlipHorizontally, 1);
                    return;
                }
                if (is_walking)
                {
                    if (timer_player < 15)
                    {
                        spriteBatch.Draw(_texture, _position, new Rectangle(
                                0, 288, 96, 96), Color.White, 0f,
                                new Vector2(_texture.Width / 6, _texture.Height / 7),
                                1, SpriteEffects.FlipHorizontally, 1);
                        return;
                    }
                    spriteBatch.Draw(_texture, _position, new Rectangle(
                            96, 288, 96, 96), Color.White, 0f,
                            new Vector2(_texture.Width / 6, _texture.Height / 7),
                            1, SpriteEffects.FlipHorizontally, 1);
                    if (timer_player == 29) timer_player = 0;
                    return;
                }
                if (timer_player < 15)
                {
                    spriteBatch.Draw(_texture, _position, new Rectangle(
                            384, 96, 96, 96), Color.White, 0f,
                            new Vector2(_texture.Width / 6, _texture.Height / 7),
                            1, SpriteEffects.FlipHorizontally, 1);
                    return;
                }
                spriteBatch.Draw(_texture, _position, new Rectangle(
                        96, 288, 96, 96), Color.White, 0f,
                        new Vector2(_texture.Width / 6, _texture.Height / 7),
                        1, SpriteEffects.FlipHorizontally, 1);
                if (timer_player == 29) timer_player = 0;
                return;
            }
        }
    }
}
