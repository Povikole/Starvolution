﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Starformers
{
    public class Sprite
    {
        public Texture2D _texture;
        public Vector2 _position;
        public Vector2 _texturePlace;
        public int sprite_width = 96;
        public int sprite_height = 96;
        public int sprite_distance_from_right = 0;
        public int sprite_distance_from_top = 0;
        public bool is_removed;
        public Sprite(Texture2D texture, Vector2 position)
        {
            _texture = texture;
            _position = position;
            _texturePlace = new Vector2(-1, -1);
        }
        public Rectangle hitbox
        {
            get
            {
                return new Rectangle((int)_position.X + sprite_distance_from_right,
                    (int)_position.Y + sprite_distance_from_top, sprite_width, sprite_height);
            }
        }
        public Sprite(Texture2D texture, Vector2 position, Vector2 texturePlace)
        {
            _texture = texture;
            _position = position;
            _texturePlace = texturePlace;
        }
        public virtual void Update(GameTime gameTime, List<Sprite> sprites)
        {
        }

        public virtual void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(_texture, _position, new Rectangle((int)_texturePlace.X * 96,
            (int)_texturePlace.Y * 96,
            96, 96), Color.White, 0f,
            new Vector2(_texture.Width / 6, _texture.Height / 7), 1, SpriteEffects.None, 1);
        }
    }
}
