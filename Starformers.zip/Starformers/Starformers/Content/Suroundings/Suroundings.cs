﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input;

namespace Starformers
{
    class Suroundings
    {
        private Texture2D texture;
        private int width, height;

        public Suroundings()
        {
        }
        public void LoadContent(ContentManager Content, List<Sprite> blocks)
        {
            texture = Content.Load<Texture2D>("Stars");

            string[] map = File.ReadAllLines("..\\..\\..\\Map1.txt");
            height = map.Length;
            Console.WriteLine(height);
            for (int i = 0; i < height; i++)
            {
                string[] parts = map[i].Split(' ');
                width = parts.Length;
                for (int j = 0; j < width; j++)
                {
                    Vector2 position = new Vector2((float)(j + 1) * 96, (float)(i + 1) * 96);
                    switch (parts[j])
                    {
                        case "W":
                            blocks.Add(new Sprite(texture, position, new Vector2(2, 5))); break;
                        case "U":
                            blocks.Add(new Block_half_UP(texture, position, new Vector2(3, 5))); break;
                        case "D":
                            blocks.Add(new Block_half_DOWN(texture, position, new Vector2(4, 5))); break;
                        case "H":
                            blocks.Add(new Blakc_hole(texture, position)); break;
                        case "F":
                            blocks.Add(new Finish(texture, position)); break;
                        case "E":
                            blocks.Add(new Energy(texture, position, new Vector2(5, 5))); break;
                        case "P":
                            blocks.Add(new Player(texture, position)
                            {
                                input = new Input() { up = Keys.Up, right = Keys.Right, left = Keys.Left,
                                    small = Keys.D1, normal = Keys.D2, big = Keys.D3, info = Keys.I, e = Keys.E}
                            }); break;
                    }
                }
            }
        }
    }
}