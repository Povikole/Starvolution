﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Starformers
{
    public class Finish : Sprite
    {
        public Finish(Texture2D texture, Vector2 position) : base(texture, position)
        {
            sprite_width = 30;
            sprite_height = 30;
            sprite_distance_from_right = 33;
            sprite_distance_from_top = 33;
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            if (Game1.timer_black_hole < 10)
            {
                spriteBatch.Draw(_texture, _position, new Rectangle(0, 576,
                    96, 96), Color.White, 0f,
                    new Vector2(_texture.Width / 6, _texture.Height / 7), 1, SpriteEffects.None, 1);
                return;
            }
            if (Game1.timer_black_hole < 20 || Game1.timer_black_hole >= 30)
            {
                spriteBatch.Draw(_texture, new Vector2(_position.X, _position.Y + 2), new Rectangle(96, 576,
                    96, 96), Color.White, 0f,
                    new Vector2(_texture.Width / 6, _texture.Height / 7), 1, SpriteEffects.None, 1);
                return;
            }
            if (Game1.timer_black_hole < 30)
            {
                spriteBatch.Draw(_texture, _position, new Rectangle(192, 576,
                    96, 96), Color.White, 0f,
                    new Vector2(_texture.Width / 6, _texture.Height / 7), 1, SpriteEffects.None, 1);
                return;
            }
        }
    }
}
