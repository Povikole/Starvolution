﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace Starformers
{
    public class Game1 : Game
    {
        public static GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;

        private Suroundings suroundings;
        public static Texture2D background, black_hole, supernova, help;
        public static Texture2D playerTexture;
        private Texture2D info, elements;
        private List<Sprite> sprites;
        private SpriteFont font;
        public static int points;
        public static bool is_dead, is_completed;
        public static Camera _camera;
        public static int screenHeight, screenWidth;
        public static bool show_info;
        public static bool show_energy;
        public static int timer_black_hole;
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            //graphics.PreferMultiSampling = false;
            graphics.IsFullScreen = true;
            graphics.ApplyChanges();
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            screenHeight = graphics.PreferredBackBufferHeight;
            screenWidth = graphics.PreferredBackBufferWidth;
            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            suroundings = new Suroundings();
            background = Content.Load<Texture2D>("Background");
            help = Content.Load<Texture2D>("Help");
            black_hole = Content.Load<Texture2D>("Black_hole");
            supernova = Content.Load<Texture2D>("Supernova");
            info = Content.Load<Texture2D>("Message");
            elements = Content.Load<Texture2D>("Elements");
            playerTexture = Content.Load<Texture2D>("Stars");
            font = Content.Load<SpriteFont>("Text");
            _camera = new Camera();
            is_dead = false;
            show_energy = false;
            show_info = false;
            timer_black_hole = 0;

            sprites = new List<Sprite>();
            suroundings.LoadContent(Content, sprites);
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            if (!is_dead)
            {
                foreach (var sprite in sprites)
                    sprite.Update(gameTime, sprites);
                foreach (var sprite in sprites.ToArray())
                {
                    if (sprite.is_removed)
                        sprites.Remove(sprite);
                }
                // TODO: Add your update logic here
                base.Update(gameTime);

            }
            if (timer_black_hole < 40) timer_black_hole++;
            else timer_black_hole = 0;
        }

        protected override void Draw(GameTime gameTime)
        {
            if (is_dead)
            {
                spriteBatch.Begin();
                spriteBatch.Draw(black_hole, new Rectangle(0, -50,
                    Game1.graphics.PreferredBackBufferWidth + 50, Game1.graphics.PreferredBackBufferWidth -100), Color.White);
                spriteBatch.DrawString(font, string.Format("Your star is gone"), new Vector2(300, 270), Color.Crimson);
                spriteBatch.End();
                return;
            }
            if (is_completed)
            {
                spriteBatch.Begin();
                spriteBatch.Draw(supernova, new Rectangle(0, -50,
                    Game1.graphics.PreferredBackBufferWidth, Game1.graphics.PreferredBackBufferWidth - 150), Color.White);
                spriteBatch.DrawString(font, string.Format("Your star has reached the endpoint!"), new Vector2(170, 255), Color.Purple);
                spriteBatch.DrawString(font, string.Format("Score: " + points), new Vector2(170, 305), Color.Purple);
                spriteBatch.End();
                return;
            }
            if (show_info)
            {
                spriteBatch.Begin();
                spriteBatch.Draw(info, new Rectangle(0, -50,
                    Game1.graphics.PreferredBackBufferWidth, Game1.graphics.PreferredBackBufferWidth-150), Color.White);
                spriteBatch.End();
                return;
            }
            if (show_energy)
            {
                spriteBatch.Begin();
                spriteBatch.Draw(elements, new Rectangle(0, -50,
                    Game1.graphics.PreferredBackBufferWidth, Game1.graphics.PreferredBackBufferWidth-150), Color.White);
                spriteBatch.End();
                return;
            }
            GraphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin();
            spriteBatch.Draw(background, new Rectangle(0, -50,
                graphics.PreferredBackBufferWidth, graphics.PreferredBackBufferWidth-150), Color.White);
            spriteBatch.End();

            // TODO: Add your drawing code here
            spriteBatch.Begin(transformMatrix: _camera.Transform);
            foreach (var sprite in sprites)
            {
                sprite.Draw(spriteBatch);
            }
            spriteBatch.End();

            spriteBatch.Begin();
            spriteBatch.DrawString(font, string.Format("ENERGY LEFT: {0}", points), new Vector2(10, 10), Color.Cyan);
            spriteBatch.End();

            if(timer_black_hole < 20)
            {
                spriteBatch.Begin();
                spriteBatch.Draw(help, new Vector2(140, 700), new Rectangle(
                                0, 0, 288, 96), Color.White, 0f,
                                new Vector2(help.Width / 2, help.Height),
                                1, SpriteEffects.None, 1);
                spriteBatch.End();
            }
            if (timer_black_hole > 19)
            {
                spriteBatch.Begin();
                spriteBatch.Draw(help, new Vector2(140, 700), new Rectangle(
                                0, 96, 288, 96), Color.White, 0f,
                                new Vector2(help.Width / 2, help.Height),
                                1, SpriteEffects.None, 1);
                spriteBatch.End();
            }

            base.Draw(gameTime);
        }
    }
}
